2010-09
How it works with LPDDR2 board?
1. Default ucl.xml is for mDDR, rename it with ucl_MDDR.xml
2. Rename ucl_LPDDR2.xml to ucl.xml

2010-10-22
1. This version is only for mx50 rdp board, and the arm2 board
is not supported any more

